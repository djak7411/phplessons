<?php
namespace app\controllers;
use yii\web\Controller;

class WeightController extends Controller
{
    public function actionWeight($height=150){
        try{
            if(($height-100)<=0){
                throw new \Exception("Рост должен быть больше 100");
            }
            else{
                $weight = $height-100;
            }
            return $this->render('weight', ['weight' => $weight]);
        }catch(\Exception $e){
            return $this->render('weight', ['weight' => $e->getMessage()]);
        }
        return null;
    }
}