<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "chelik".
 *
 * @property int $id
 * @property int $iq
 * @property double $rating
 * @property string $name
 */
class Chelik extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'chelik';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['iq'], 'integer'],
            [['rating'], 'number'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'iq' => 'Iq',
            'rating' => 'Rating',
            'name' => 'Name',
        ];
    }
}
