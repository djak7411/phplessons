<?php
use yii\helpers\html;
?>
<?= HTML::encode($weight);?>