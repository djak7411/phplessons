<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%skill}}`.
 */
class m190208_112552_create_skill_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%skill}}', [
            'id' => $this->primaryKey(),
            'tag' => $this->string(),
            'quality' => $this->float(),
            'popularity' => $this->integer(),
            'worker_id' => $this->integer()
        ]);


        $this->addForeignKey(
            'fk-skill-worker_id',
            'skill',
            'worker_id',
            'worker',
            'id',
            'CASCADE'
        );

       // $this->alterColumn('skill', 'id', $this->smallInteger(8).' NOT NULL AUTO_INCREMENT');

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%skill}}');
    }
}
